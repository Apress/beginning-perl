#!/usr/bin/perl -w

print "Hello, world!\n";
