#!/usr/bin/perl -w
# arithop1.pl

print 69 + 118, "\n";
