#!/usr/bin/perl -w
# arithop2.pl

print "21 from 25 is: ", 25 - 21, "\n";
print "4 + 13 - 7 is: ", 4 + 13 - 7, "\n";
