#!/usr/bin/perl -w
# arithop4.pl

print 3 + 7 * 15, "\n";
