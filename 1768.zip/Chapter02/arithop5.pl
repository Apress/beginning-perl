#!/usr/bin/perl -w
# arithop5.pl

print (3 + 7) * 15, "\n";
