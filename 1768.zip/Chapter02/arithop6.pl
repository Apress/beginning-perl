#!/usr/bin/perl -w
# arithop6.pl

print((3 + 7) * 15, "\n");
