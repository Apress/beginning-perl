#!/usr/bin/perl -w
# arithop7.pl

print 2**4, " ", 3**5, " ", -2**4, "\n";
