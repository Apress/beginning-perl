#!/usr/bin/perl -w
# arithop8.pl

print "15 divided by 6 is exactly ", 15 / 6, "\n";
print "That's a remainder of ", 15 % 6, "\n";
