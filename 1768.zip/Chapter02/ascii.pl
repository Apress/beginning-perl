#!/usr/bin/perl -w
# ascii.pl

print "A # has ASCII value ", ord("#"), "\n";
print "A * has ASCII value ", ord("*"), "\n";
