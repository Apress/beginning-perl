#!/usr/bin/perl -w
# aside1.pl

print 'ex\\ er\\' , ' ci\' se\'' , "\n";
