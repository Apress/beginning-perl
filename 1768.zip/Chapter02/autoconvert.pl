#!/usr/bin/perl -w
# autoconvert.pl

print "0.25" * 4, "\n";
