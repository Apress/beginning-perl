#!/usr/bin/perl -w
# bitop1.pl

print "51 ANDed with 85 gives us ", 51 & 85, "\n";
