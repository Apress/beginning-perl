#!/usr/bin/perl -w
# bitop2.pl

print "NOT 85 is ", ~85, "\n";
