#!/usr/bin/perl -w
# bool1.pl

print "Is two equal to four? ",          2 == 4, "\n";
print "OK, then, is six equal to six? ", 6 == 6, "\n";
