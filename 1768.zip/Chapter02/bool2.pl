#!/usr/bin/perl -w
# bool2.pl

print "So, two isn't equal to four? ", 2 != 4, "\n";
