#!/usr/bin/perl -w
# currency1.pl

use strict;

my $yen = 105.6;   # as of 02 February 2004

print "49518 Yen is ", (49_518/$yen), " dollars\n";
print "360 Yen is   ", (   360/$yen), " dollars\n";
print "30510 Yen is ", (30_510/$yen), " dollars\n";
