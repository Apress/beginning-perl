#!/usr/bin/perl -w
# die.pl

use strict;

print "enter a string to pass to die: ";
chomp(my $string = <STDIN>);

die($string);

print "didn't make it this far...\n";

