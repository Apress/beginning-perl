#!/usr/bin/perl -w
# goodnums.pl

print 255,        "\n";
print 0377,       "\n";
print 0b11111111, "\n";
print 0xFF,       "\n";
