#!/usr/bin/perl -w
# number1.pl

print 25, -4;
