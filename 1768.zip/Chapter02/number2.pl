#!/usr/bin/perl -w
# number2.pl

print 25, " ", -4, "\n";
