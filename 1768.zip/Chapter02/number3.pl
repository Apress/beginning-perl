#!/usr/bin/perl -w
# number3.pl

print 25_000_000, " ", -4, "\n";
