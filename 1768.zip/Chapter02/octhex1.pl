#!/usr/bin/perl -w  
# octhex1.pl

print "0x30\n";
print "030\n";
