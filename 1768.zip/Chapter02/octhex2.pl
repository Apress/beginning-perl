#!/usr/bin/perl -w
# octhex2.pl

print hex("0x30"), "\n";
print oct("030"), "\n";
