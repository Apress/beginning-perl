#!/usr/bin/perl -w
# octhex3.pl

print hex("FFG"), "\n";
print oct("178"), "\n";
