#!/usr/bin/perl -w
# quotes.pl

print '\tThis is a single quoted string.\n';
print "\tThis is a double quoted string.\n";
