#!/usr/bin/perl -w
# quotes2.pl

print "C:\\WINNT\\Profiles\\\n";
print 'C:\WINNT\Profiles\ ', "\n";
