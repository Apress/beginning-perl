#!/usr/bin/perl -w
# quotes3.pl

print "It's as easy as that.\n";
print '"Stop," he cried.', "\n";
