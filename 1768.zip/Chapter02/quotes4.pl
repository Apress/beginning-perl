#!/usr/bin/perl -w
# quotes4.pl

print "'\"Hi,\" said Jack. \"Have you read Slashdot today?\"'\n";
