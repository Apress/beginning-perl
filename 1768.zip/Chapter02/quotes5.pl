#!/usr/bin/perl -w
# quotes5.pl

print qq/'"Hi," said Jack. "Have you read Slashdot today?"'\n/;
