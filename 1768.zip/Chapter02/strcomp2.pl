#!/usr/bin/perl -w 
# strcomp2.pl

print "Test one: ", "four" eq "six", "\n";
print "Test two: ", "four" == "six", "\n";
