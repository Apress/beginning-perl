#!/usr/bin/perl -w
# string1.pl

print "Four sevens are ". 4*7 ."\n";
