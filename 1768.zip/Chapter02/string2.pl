#!/usr/bin/perl -w
# string2.pl

print "GO! " x 3, "\n";
