#!/usr/bin/perl -w
# string3.pl

print "Ba" . "na" x 4 ,"\n";
