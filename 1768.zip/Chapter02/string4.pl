#!/usr/bin/perl -w
# string4.pl

print "Ba" . "na" x 4*3 ,"\n";
print "Ba" . "na" x (4*3) ,"\n";
