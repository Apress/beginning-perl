#!/usr/bin/perl -w
# varint1.pl

use strict;

my $name = "fred";
print "My name is $name\n";
