#!/usr/bin/perl -w
# varint2.pl

use strict;

my $name = "fred";
print 'My name is $name\n';
