#!/usr/bin/perl -w
# varint3.pl

use strict;

my $name = "fred";
my $salutation = "Dear $name,";
print $salutation, "\n";
