#!/usr/bin/perl -w
# varint4.pl

use strict;

my $times = 8;
print "This is the ${times}th time.\n";
