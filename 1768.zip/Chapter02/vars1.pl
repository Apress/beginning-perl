#!/usr/bin/perl -w
# vars1.pl

$name = "fred";
print "My name is ", $name, "\n";
