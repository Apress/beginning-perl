#!/usr/bin/perl -w
# defined.pl

use strict;

my ($a, $b);
$b = 10;

if (defined $a) {
    print "\$a has a value.\n";
}
if (defined $b) {
    print "\$b has a value.\n";
}
