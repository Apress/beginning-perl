#!/usr/bin/perl -w
# emptylist.pl

use strict;

if ( (()) ) {
    print "Yes, it is.\n";
}
