#!/usr/bin/perl -w
# foreach.pl

use strict;

my $number;

foreach $number (1 .. 10) {
    print "the number is: $number\n";
}
