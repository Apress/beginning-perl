#!/usr/bin/perl -w
# last1.pl

use strict;

while (<STDIN>) {
    if ($_ eq "done\n") {
	last;
    }
    print "You entered: $_";
}

print "All done!\n";
