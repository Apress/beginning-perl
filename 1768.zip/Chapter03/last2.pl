#!/usr/bin/perl -w
# last2.pl

use strict;

while (<STDIN>) {
    last if $_ eq "done\n";
    print "You entered: $_";
}

print "All done!\n";
