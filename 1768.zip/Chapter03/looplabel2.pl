#!/usr/bin/perl -w
# looplabel2.pl

use strict;

my $i = 1;

OUTER: while ($i <= 5) {
    my $j = 1;
    while ($j <= 5) {
        last OUTER if $j == 3;
	print "$i ** $j = ", $i ** $j, "\n";
	$j++;
    }
    $i++;
}
