#!/usr/bin/perl -w
# next1.pl

use strict;

print "Please enter some text:\n";
while (<STDIN>) {
    if ($_ eq "\n") {
        next;
    }
    chomp;
    print "You entered: [$_]\n";
}
