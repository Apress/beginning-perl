#!/usr/bin/perl -w
# next2.pl

use strict;

print "Please enter some text:\n";
while (<STDIN>) {
    next if $_ eq "\n";
    chomp;
    print "You entered: [$_]\n";
}
