#!/usr/bin/perl -w
# while1.pl

use strict;

my $countdown = 5;

while ($countdown > 0) {
    print "Counting down: $countdown\n";
    $countdown--;
}
