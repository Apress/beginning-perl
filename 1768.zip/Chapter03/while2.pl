#!/usr/bin/perl -w
# while3.pl

use strict;

while (<STDIN>) {
    print "You entered: ";
    print;
}
