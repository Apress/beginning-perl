#!/usr/bin/perl -w
# while2.pl

use strict;

my $countdown = 5;

while ($countdown > 0) {
    print "Counting down: $countdown\n";
}
