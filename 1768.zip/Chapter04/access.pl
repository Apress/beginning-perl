#!/usr/bin/perl -w
# access.pl

use strict;

print(('salt', 'vinegar', 'mustard', 'pepper')[2]);
print "\n";
