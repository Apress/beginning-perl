#!/usr/bin/perl -w
# argv1.pl

use strict;

print "contents of @ARGV:\n";
print "[$_]\n" foreach @ARGV;
print "\$0: $0\n";
