#!/usr/bin/perl -w
# argv2.pl

use strict;

print "program arguments:\n";

my $i = 0;

while ($i <= $#ARGV) {
    print "argument $i: $ARGV[$i]\n";
    $i++;
}
