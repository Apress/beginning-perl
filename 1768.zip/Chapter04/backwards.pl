#!/usr/bin/perl -w
# backwards.pl

use strict;

print qw(
	January	February	March 
	April	May		June 
	July	August		September
	October	November	December
)[-1];
