#!/usr/bin/perl -w
# baddayarray1.pl

use strict;

my @days;
@days = qw(Monday Tuesday Wednesday Thursday Friday Saturday Sunday);
$days = 31;
