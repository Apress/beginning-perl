#!/usr/bin/perl -w
# countdown.pl

use strict;

my @count = (1..5);

foreach (reverse(@count)) {
    print "$_...\n";
    sleep 1;
}

print "BLAST OFF!\n";
