#!/usr/bin/perl -w
# dayarray.pl

use strict;

my @days;
@days = qw(Monday Tuesday Wednesday Thursday Friday Saturday Sunday);
print @days, "\n";
