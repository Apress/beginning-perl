#!/usr/bin/perl -w
# foreach1.pl

use strict;

my $element;

foreach $element ('zero', 'one', 'two') {
    print "the element is: $element\n";
}
