#!/usr/bin/perl -w
# foreach2.pl

use strict;

my @array = qw(America Asia Europe Africa);
my $element;

foreach $element (@array) {
    print $element, "\n";
}
