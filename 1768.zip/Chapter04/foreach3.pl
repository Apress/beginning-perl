#!/usr/bin/perl -w
# foreach3.pl

use strict;

my @array = (1, 3, 5, 7, 9);
foreach my $i (@array) {
    print "This element: $i\n";
}
	
