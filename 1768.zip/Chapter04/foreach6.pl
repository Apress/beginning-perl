#!/usr/bin/perl -w
# foreach6.pl

use strict;

my @a = qw(hello world good bye);

print "[$_]\n" foreach @a;
