#!/usr/bin/perl -w
# mixedlist.pl

use strict;

my $test = 30;

print 
    "Here is a list containing strings, (this one) ", 
    "numbers (",
    3.6, 
    ") and variables: ", 
    $test, 
    "\n"
    ;
