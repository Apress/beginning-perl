#!/usr/bin/perl -w
# numberlist.pl

use strict;

print(123, 456, 789);
