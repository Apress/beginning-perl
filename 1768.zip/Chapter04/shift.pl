#!/usr/bin/perl -w
# shift.pl

use strict;

my @array = ();
unshift @array, "first";
print "Array is now: @array\n";
unshift @array, "second", "third";
print "Array is now: @array\n";
shift @array ;
print "Array is now: @array\n";
