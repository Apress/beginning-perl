#!/usr/bin/perl -w
# each.pl

use strict;

my %where = (
	Gary     => "Dallas",
	Lucy     => "Exeter",
	Ian      => "Reading",
	Samantha => "Oregon"
);

my($k, $v);
while (($k, $v) = each %where) {
    print "$k lives in $v\n";
}
