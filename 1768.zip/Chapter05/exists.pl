#!/usr/bin/perl -w
# exists.pl

use strict;

my %where = (
	Gary     => "Dallas",
	Lucy     => "Exeter",
	Ian      => "Reading",
	Samantha => "Oregon"
);

print "Gary exists in the hash!\n"  if exists $where{Gary};
print "Larry exists in the hash!\n" if exists $where{Larry};
