#!/usr/bin/perl -w
# hash.pl

use strict;

my $who = "Ian";

my %where = (
	Gary     => "Dallas",
	Lucy     => "Exeter",
	Ian      => "Reading",
	Samantha => "Oregon"
);

print "Gary lives in ", $where{Gary}, "\n";
print "$who lives in $where{$who}\n";
