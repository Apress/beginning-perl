#!/usr/bin/perl -w
# keys.pl

use strict;

my %where = (
	Gary     => "Dallas",
	Lucy     => "Exeter",
	Ian      => "Reading",
	Samantha => "Oregon"
);

foreach (keys %where) {
    print "$_ lives in $where{$_}\n";
}
