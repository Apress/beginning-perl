#!/usr/bin/perl -w
# reverse.pl

use strict;

my %where = (
    Gary     => "Dallas",
    Lucy     => "Exeter",
    Ian      => "Reading",
    Samantha => "Oregon"
);

my %who = reverse %where;

foreach (keys %who) {
    print "in $_ lives $who{$_}\n";
}
