#!/usr/bin/perl -w
# values.pl

use strict;

my %where = (
	Gary     => "Dallas",
	Lucy     => "Exeter",
	Ian      => "Reading",
	Samantha => "Oregon"
);

foreach (values %where) {
    print "someone lives in $_\n";
}
