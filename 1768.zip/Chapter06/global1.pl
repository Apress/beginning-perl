#!/usr/bin/perl -w
# global1.pl

$x = 10;

access_global();

sub access_global {
    print "value of \$x: $x\n";
}
