#!/usr/bin/perl -w
# strict1.pl

use strict;

$x = 10;
print $x;
