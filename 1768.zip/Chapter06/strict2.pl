#!/usr/bin/perl -w
# strict2.pl

use strict;

$main::x = 10;
print $main::x, "\n";
