#!/usr/bin/perl -w
# subdecl.pl

use strict;

setup;

sub setup {
    print "This is some program, version 0.1\n";
}
