#!/usr/bin/perl -w
# rhyming.pl

use strict;

my $syllable = "ink";

while (<>) {
    print if /$syllable$/;
}
