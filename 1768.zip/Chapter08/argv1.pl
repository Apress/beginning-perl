#!/usr/bin/perl -w
# argv1.pl

use strict;

print "[$_]\n" foreach @ARGV;
