#!/usr/bin/perl -w
# diamond1.pl

use strict;

while (<>) {
    print "text read: $_"
}
