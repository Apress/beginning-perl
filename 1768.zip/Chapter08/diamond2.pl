#!/usr/bin/perl -w
# diamond2.pl

use strict;

@ARGV = qw/file1.txt file2.txt file3.txt/;

while (<>) {
    print;
}
