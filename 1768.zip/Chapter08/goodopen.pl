#!/usr/bin/perl -w
# goodopen.pl

use strict;

open(FH, '<', 'goodopen.dat') or die $!;

print "goodopen.dat opened successfully\n";

close FH;
