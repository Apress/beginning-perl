#!/usr/bin/perl -w
# nl1.pl

use strict;

open(FILE, '<', 'nlexample.txt') or die $!;
my $lineno = 1;

while (<FILE>) {
    print $lineno++;
    print ": $_";
}

close FH;
