#!/usr/bin/perl -w
# nl2.pl

use strict;

my $lineno = 1;

while (<>) {
    print $lineno++;
    print ": $_";
}
