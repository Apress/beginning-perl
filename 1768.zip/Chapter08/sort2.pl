#!/usr/bin/perl -w
# sort2.pl

use strict;

my @text = <>;

print sort @text;
