#!/usr/bin/perl -w
# tail2.pl

use strict;

open(FILE, '<', 'gettysburg.txt') or die $!;
my @speech = <FILE>;   # slurp the whole file into memory
close FILE;

print "Last five lines:\n", @speech[-5 .. -1];
