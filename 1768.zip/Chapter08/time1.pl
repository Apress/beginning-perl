#!/usr/bin/perl -w
# time1.pl

use strict;

foreach (1..20) {
    print ".";
    sleep 1;
} 
print "\n";
