#!/usr/bin/perl -w
# time2.pl

use strict;

$| = 1;
foreach (1..20) {
    print ".";
    sleep 1;
} 
print "\n";
