#!/usr/bin/perl -w
# length.pl

use strict;

my $song = 'The Great Gig in the Sky';
print 'length of $song: ', length($song), "\n";
# well, the *real* length is 4:44

$_ = 'Us and Them';
print 'length of $_: ', length, "\n";
# this one is 7:40

