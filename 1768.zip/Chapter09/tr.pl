#!/usr/bin/perl -w
# tr.pl

while (<>) {
    tr/a-z/A-Z/;
    print;
}
