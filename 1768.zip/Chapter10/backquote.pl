#!/usr/bin/perl -w
# backquote.pl

use strict;

my $command = 'ls *.pl';

my $result = `$command`;

print "backquotes error status: $?\n";
print "backquotes returned:\n";
print "$result\n\n";

print "using a string literal:\n";
print `date`;
print "backquotes error status: $?\n";
