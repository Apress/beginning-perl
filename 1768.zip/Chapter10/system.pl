#!/usr/bin/perl -w
# system.pl

use strict;

my $error_status = system 'date';

print "system() returned: $error_status\n";
