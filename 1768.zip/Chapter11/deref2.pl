#!/usr/bin/perl -w
# deref2.pl

use strict;

my @band = qw(Crosby Stills Nash Young);
my $ref  = \@band;
foreach (0..$#band) {
    print "Array    : ", $band[$_]  , "\n";
    print "Reference: ", ${$ref}[$_], "\n";
}
