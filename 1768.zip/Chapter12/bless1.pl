#!/usr/bin/perl -w
# bless1.pl

use strict;

my $a = {};

print '$a is a ', ref($a), " reference\n";

bless ($a, "Person1");

print '$a is a ', ref($a), " reference\n";
