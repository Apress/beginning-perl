#!/usr/bin/perl -w
# cantload.pl

use strict;

require "nothere.pl";
