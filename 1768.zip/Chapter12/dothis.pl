#!/usr/bin/perl -w
# dothis.pl

use strict;

my $a = "Been there, done that, got the T-shirt";
do "printit.pl";
