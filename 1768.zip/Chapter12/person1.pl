#!/usr/bin/perl -w
# person1.pl

use strict;
use Person1;
