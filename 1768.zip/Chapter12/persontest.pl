#!/usr/bin/perl -w
# persontest.pl

use strict;
use Person2;

my $person = Person2->new();
