print $a;
print "this should go to standard output...\n";
