#!/usr/bin/perl -w
# benchtest1.pl

use strict;
use Benchmark;

my $howmany = 10000;
my $what    = q/my $j=1; foreach (1..100) {$j *= $_}/;

timethis($howmany, $what);
