#!/usr/bin/perl -w
# benchtest2.pl

use strict;
use Benchmark;

my $howmany = 100;

timethese($howmany, {
    line => q{
	my $file;
	open TEST, "words" or die $!;
	while (<TEST>) { $file .= $_ }
	close TEST;
    },
    slurp => q{
	my $file;
	local undef $/;
	open TEST, "words" or die $!;
	$file = <TEST>;
	close TEST;
    },
    join => q{
	my $file;
	open TEST, "words" or die $!;
	$file = join "", <TEST>;
	close TEST;
    }
});
