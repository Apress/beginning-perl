#!/usr/bin/perl -w
# hoover.pl

use strict;
use File::Find;

find(\&cleanup, "/");

sub cleanup {
   # Not been accessed in six months?
    if (-A > 180) {
	print "Deleting old file $_\n";
	unlink $_ or print "oops, couldn't delete $_: $!\n";
	return;
    }
    open (FH, $_) or die "Couldn't open $_: $!\n";
    foreach (1..5) { # You've got five chances.
	my $line = <FH>;
	if ($line =~ /Perl|Camel|important/i) {
         # Spare it.
	    return;
	}
    }
    print "Deleting unimportant file $_\n";
    unlink $_ or print "oops, couldn't delete $_: $!\n";
}
