#!/usr/bin/perl -w
# cgi2.pl

# this program generates HTML with the use
# of CGI.pm using the conventional style

use strict;
use CGI ':standard';

print 
    header(),
    start_html('Generating HTML'),
    h1('Now Is:'),
    p('The current date and time is:', scalar(localtime)),
    hr(),
    h1('Our CGI Scripts');

my $file_listing = '';
$file_listing .= "<br />$_" foreach <*.pl>;

print
     p('By the time this chapter is over, you will write all of',
        'these scripts:', $file_listing),
     h1('Go Here For Excellent Books!'),
     p('Check out the',
       a({ href => 'http://www.apress.com/' }, 'Apress Home Page')),
     end_html();
