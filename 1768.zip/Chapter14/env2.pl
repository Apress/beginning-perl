#!/usr/bin/perl -w
# env2.pl

use strict;

print "Content-Type: text/plain\n";
print "\n";

foreach (sort keys %ENV) {
    print "$_ = $ENV{$_}\n";
}
