#!/usr/bin/perl -w
# env3.pl

use strict;

print "Content-Type: text/html\n";
print "\n";

foreach (sort keys %ENV) {
    print "$_ = $ENV{$_}";
    print "<br>";
}
