#!/usr/bin/perl -w
# hello.pl

use strict;

print "Content-Type: text/plain\n";
print "\n";
print "hello, world!\n";
